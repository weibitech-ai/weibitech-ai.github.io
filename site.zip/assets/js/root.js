document.addEventListener('click',function(e){var a=e.target.closest&&e.target.closest('a[data-setlang]');if(a){try{localStorage.setItem('wb-lang',a.getAttribute('data-setlang'))}catch(err){}}});
